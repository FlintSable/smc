


alertType = (x) => {
	alert(typeof x);
}

var gundam = {type:"gundam", model:"RX-78-1 ", color:"white"};
alertType(gundam)

