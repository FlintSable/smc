window.onload = () => {
	console.log('windows has loaded');

};


var obot = document.getElementById('robo');
var container = document.getElementById('container');
var zerozero = 0;

function move(){
	obot.style.left = parseInt(obot.style.left) + 10 + 'px';

}

var ButtonState = document.getElementById('bott');

ButtonState.addEventListener('click', () => {
	ButtonState.innerHTML = 'pause';

});



function keymove(e){



	if(e.keyCode == 39){
		console.log(e.keyCode)
		zerozero += 20;
		obot.style.left = zerozero + 'px';
		console.log(ButtonState.innerHTML);
	};
	if(e.keyCode == 37){
		console.log(e.keyCode)
		zerozero -= 20;
		obot.style.left = zerozero + 'px'
	};

}

document.onkeydown = keymove;


