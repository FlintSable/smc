// Nicholas Noochla-or 3/18/2018 
// assignment unit 2
// local variable
let introduction = "Hello, World!"
// practicing Template literals
alert(`${introduction}`);
console.log(`${introduction}`);


// first solution
// alert(introduction)
// console.log(introduction)

